
package assignment.pkg3;


public class Assignment3 {

    
    public static void main(String[] args) {
        design d=new design();
    }
    
}
